function Shop() {
    this.construct = function (builder) {
        builder.step1();
        builder.step2();
        return builder.get();
    }
}

function HiluxBuilder() { // TOYOTA HILUX
    this.hilux = null;

    this.step1 = function () {
        this.hilux = new Hilux();
    };

    this.step2 = function () {
        this.hilux.addParts();
    };

    this.get = function () {
        return this.hilux;
    };
}

function HiaceBuilder() { // TOYOTA HIACE
    this.hiace = null;

    this.step1 = function () {
        this.hiace = new Hiace();
    };

    this.step2 = function () {
        this.hiace.addParts();
    };

    this.get = function () {
        return this.hiace;
    };
}

function CorollaBuilder() { // TOYOTA COROLLA
    this.corolla = null;

    this.step1 = function () {
        this.corolla = new Corolla();
    };

    this.step2 = function () {
        this.corolla.addParts();
    };

    this.get = function () {
        return this.corolla;
    };
}

function Hilux() {
    this.doors = 0;

    this.addParts = function () {
        this.doors = 4;
    };

    this.say = function () {
        log.add("¿Seguro que quieres a Chikorita como tu acompañante?");
    };
}

function Hiace() {
    this.doors = 0;

    this.addParts = function () {
        this.doors = 3;
    };

    this.say = function () {
        log.add("¿Seguro que quieres a Totodile como tu acompañante?");
    };
}

function Corolla() {
    this.doors = 0;

    this.addParts = function () {
        this.doors = 4;
    };

    this.say = function () {
        log.add("¿Seguro que quieres a Cyndaquil como tu acompañante?");
    };
}

// log helper
var log = (function () {
    var log = "";
    return {
        add: function (msg) { log += msg + "\n"; },
        show: function () { swal(log); log = ""; }
    }
})();

function runHilux() {
    // Utilizando elementos del DOM para mostrar en los <p> del <alert>.
    var marca = "CHIKORITA.", modelo = "Planta", motor = "Espesura ", precio = "Un dulce aroma se desprende de la hoja de su cabeza. Es dócil y le encanta absorber los rayos de sol. ";
    pmarca = document.getElementById("marca");
    pmodelo = document.getElementById("modelo");
    pmotor = document.getElementById("motor");
    pprecio = document.getElementById("precio");
    pmarca.innerHTML = "Nombre: " + marca;
    pmodelo.innerHTML = "Tipo: " + modelo;
    pmotor.innerHTML = "Habilidad: " + motor;
    pprecio.innerHTML = "Descripción: " + precio;
    // Mostramos imagen del carro, con el DOM.
    img = document.getElementById("imgCars");
    img.innerHTML = '<img src="img/chikorita.png" height="300px" width="350px" />';

    var shop = new Shop();
    var hiluxBuilder = new HiluxBuilder();
    var carHilux = shop.construct(hiluxBuilder);

    carHilux.say();
    log.show();
}
function runHiace() {
    // Utilizando elementos del DOM para mostrar en los <p> del <alert>.
    var marca = "TOTODILE", modelo = "Agua", motor = "Torrente", precio = "Sus desarrolladas y potentes fauces pueden romper cualquier cosa. Su entrenador debe tener cuidado.";
    pmarca = document.getElementById("marca");
    pmodelo = document.getElementById("modelo");
    pmotor = document.getElementById("motor");
    pprecio = document.getElementById("precio");
    pmarca.innerHTML = "Nombre: " + marca;
    pmodelo.innerHTML = "Tipo: " + modelo;
    pmotor.innerHTML = "Habilidad: " + motor;
    pprecio.innerHTML = "Descripción: " + precio;
    // Mostramos imagen del carro, con el DOM.
    img = document.getElementById("imgCars");
    img.innerHTML = '<img src="img/totodile.png" height="300px" width="350px" />';

    var shop = new Shop();
    var hiaceBuilder = new HiaceBuilder();
    var carHiace = shop.construct(hiaceBuilder);

    carHiace.say();
    log.show();
}
function runCorolla() {
    // Utilizando elementos del DOM para mostrar en los <p> del <alert>.
    var marca = "CYNDAQUIL.", modelo = "Fuego", motor = "Mar Llamas", precio = "Cuando se enfada, el fuego que dispara por el lomo es infernal. Las llamaradas intimidan a sus rivales.";
    pmarca = document.getElementById("marca");
    pmodelo = document.getElementById("modelo");
    pmotor = document.getElementById("motor");
    pprecio = document.getElementById("precio");
    pmarca.innerHTML = "Nombre: " + marca;
    pmodelo.innerHTML = "Tipo: " + modelo;
    pmotor.innerHTML = "Habilidad: " + motor;
    pprecio.innerHTML = "Descripción: " + precio;
    // Mostramos imagen del carro, con el DOM.
    img = document.getElementById("imgCars");
    img.innerHTML = '<img src="img/cyn.png" height="300px" width="350px" />';

    var shop = new Shop();
    var corollaBuilder = new CorollaBuilder();
    var carCorolla = shop.construct(corollaBuilder);

    carCorolla.say();
    log.show();
}